-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Дек 20 2017 г., 16:37
-- Версия сервера: 10.1.28-MariaDB
-- Версия PHP: 7.1.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `MORNING_STAR`
--

-- --------------------------------------------------------

--
-- Структура таблицы `dogs`
--

CREATE TABLE `dogs` (
  `id` int(11) NOT NULL,
  `path` varchar(64) NOT NULL,
  `path_mini` varchar(80) NOT NULL,
  `title` varchar(40) NOT NULL,
  `description` varchar(512) NOT NULL,
  `dog_page_dir` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `dogs`
--

INSERT INTO `dogs` (`id`, `path`, `path_mini`, `title`, `description`, `dog_page_dir`) VALUES
(238, '../data/uploads/images/stella.jpg', '../data/uploads/images/mini/stella.jpg', 'Стелла', 'Чемпион России.', './stella.php'),
(239, '../data/uploads/images/ledi.jpg', '../data/uploads/images/mini/ledi.jpg', 'Леди', 'Гранд чемпион России.', './ledi.php'),
(240, '../data/uploads/images/trimming,_gruming..jpg', '../data/uploads/images/mini/trimming,_gruming..jpg', 'Триминг', 'Груминг. Профессиональная подготовка к выставке.', './triming.php');

-- --------------------------------------------------------

--
-- Структура таблицы `reserve_puppy`
--

CREATE TABLE `reserve_puppy` (
  `id` int(11) NOT NULL,
  `user_id` varchar(16) NOT NULL,
  `user_name` varchar(32) NOT NULL,
  `user_phone` varchar(20) NOT NULL,
  `user_email` varchar(40) NOT NULL,
  `date` varchar(24) NOT NULL,
  `dog_mother_id` varchar(8) NOT NULL,
  `male_or_female` varchar(11) NOT NULL,
  `user_message` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Таблица резервирования щенков.';

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `login` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `date` varchar(32) NOT NULL,
  `name` varchar(32) NOT NULL,
  `email` varchar(48) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `admin` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `user`
--

INSERT INTO `user` (`id`, `login`, `password`, `date`, `name`, `email`, `phone`, `admin`) VALUES
(1, 'Artem', 'eb8932758ff316816ba9dc66ba8384e7', '24.11.2017 17:08:53', 'Артем Кузнецов', '', '', 'true'),
(30, 'Olesya', '07ed579cf502efc0d7a0ea86c6c7162a', '5.12.2017 6:34:20', 'Олеся', 'olesya.kuznecova.samara@gmail.com', '89608175048', ''),
(31, 'Petr', 'e30fab43de43ad315a1c03801b488aef', '6.12.2017 6:15:57', 'Петр Иванович', '', '', ''),
(32, 'Oleg', 'f269cd411a81c5f8dba78fa7f6bf90ab', '6.12.2017 20:04:28', 'Олег', 'oleg@sdsds.sds', '', '');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `dogs`
--
ALTER TABLE `dogs`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `reserve_puppy`
--
ALTER TABLE `reserve_puppy`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `dogs`
--
ALTER TABLE `dogs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=241;

--
-- AUTO_INCREMENT для таблицы `reserve_puppy`
--
ALTER TABLE `reserve_puppy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT для таблицы `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
