-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Ноя 28 2017 г., 18:16
-- Версия сервера: 10.1.28-MariaDB
-- Версия PHP: 7.1.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `MORNING_STAR`
--

-- --------------------------------------------------------

--
-- Структура таблицы `uploads_dogs`
--

CREATE TABLE `uploads_dogs` (
  `id` int(11) NOT NULL,
  `path` varchar(64) NOT NULL,
  `title` varchar(40) NOT NULL,
  `description` varchar(512) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `uploads_dogs`
--

INSERT INTO `uploads_dogs` (`id`, `path`, `title`, `description`) VALUES
(62, '../data/uploads/images/Ledi.jpg', 'ывыфв', 'ывыфвф'),
(63, '../data/uploads/images/Trimming,_gruming..jpg', '12екпываыывам', '23с4123123с');

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `login` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `date` varchar(32) NOT NULL,
  `name` varchar(32) NOT NULL,
  `email` varchar(32) NOT NULL,
  `admin` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `user`
--

INSERT INTO `user` (`id`, `login`, `password`, `date`, `name`, `email`, `admin`) VALUES
(1, 'Artem', 'eb8932758ff316816ba9dc66ba8384e7', '24.11.2017 17:08:53', 'Артем Кузнецов', '', 'true'),
(21, '2', 'ba616fd0baf99b05bfa375e34922c896', '26.11.2017 12:37:13', '2', '', '0'),
(22, '3', '96987765ac64b12e796bb1aeeccebe00', '26.11.2017 15:26:45', '3', '', '0'),
(23, '1', 'af863e21378a5414fbcd22f17eb1864a', '26.11.2017 16:19:55', '1', '', '');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `uploads_dogs`
--
ALTER TABLE `uploads_dogs`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `uploads_dogs`
--
ALTER TABLE `uploads_dogs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT для таблицы `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
