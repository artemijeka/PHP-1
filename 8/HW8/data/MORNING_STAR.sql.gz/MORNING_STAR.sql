-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Ноя 25 2017 г., 06:23
-- Версия сервера: 10.1.28-MariaDB
-- Версия PHP: 7.1.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `MORNING_STAR`
--

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `login` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `date` varchar(32) NOT NULL,
  `name` varchar(32) NOT NULL,
  `email` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `user`
--

INSERT INTO `user` (`id`, `login`, `password`, `date`, `name`, `email`) VALUES
(1, 'Artem', 'eb8932758ff316816ba9dc66ba8384e7', '24.11.2017 17:08:53', 'Артем Кузнецов', ''),
(2, 'Petr', 'e30fab43de43ad315a1c03801b488aef', '24.11.2017 17:12:33', 'Петр', ''),
(3, 'Ivan', '0cb2c837316029127004b517b0092ccb', '24.11.2017 18:16:49', 'Иван Дулин', ''),
(4, 'Stepan', '178bf1d47adf9094720fe07f0d895e5b', '24.11.2017 18:18:21', 'Степан Разин', ''),
(5, 'Igor', '671c6ba858a76838fd228d802b060e42', '24.11.2017 18:23:39', 'Игорь', ''),
(6, 'Sasha', '393df4b8b554341c087170b95e62c92b', '24.11.2017 18:58:59', 'Саша', ''),
(10, 'Vasya', '4c608b02182657df66b0041f1b4a1e42', '25.11.2017 8:52:37', 'Вася', ''),
(11, 'Alisa', '4b922f1d92131e08cfede3a4eccb0d6d', '25.11.2017 8:53:49', 'Алиса', ''),
(12, 'Valera', '35876ac10497593a1611a7239efb14b4', '25.11.2017 9:18:50', 'Валера', '');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
