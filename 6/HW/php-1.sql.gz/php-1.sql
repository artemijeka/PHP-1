-- phpMyAdmin SQL Dump
-- version 4.7.2
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Ноя 14 2017 г., 17:24
-- Версия сервера: 10.1.26-MariaDB
-- Версия PHP: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `php-1`
--

-- --------------------------------------------------------

--
-- Структура таблицы `lesson_5`
--

CREATE TABLE `lesson_5` (
  `ID` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `way` varchar(100) NOT NULL,
  `size` int(11) NOT NULL,
  `hits` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `lesson_5`
--

INSERT INTO `lesson_5` (`ID`, `name`, `way`, `size`, `hits`) VALUES
(120, '2.jpg', '../data/uploads/', 85699, 0),
(121, '1.jpg', '../data/uploads/', 137800, 2),
(122, '4.jpg', '../data/uploads/', 50445, 0),
(123, '5.jpg', '../data/uploads/', 425422, 4);

-- --------------------------------------------------------

--
-- Структура таблицы `lesson_6`
--

CREATE TABLE `lesson_6` (
  `id` int(11) NOT NULL,
  `userNumber` int(11) NOT NULL,
  `operation` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `lesson_6_reviews`
--

CREATE TABLE `lesson_6_reviews` (
  `id` int(11) NOT NULL,
  `userName` varchar(64) NOT NULL,
  `userEmail` varchar(64) NOT NULL,
  `review` varchar(1000) NOT NULL,
  `currentDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `lesson_5`
--
ALTER TABLE `lesson_5`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `lesson_6`
--
ALTER TABLE `lesson_6`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Индексы таблицы `lesson_6_reviews`
--
ALTER TABLE `lesson_6_reviews`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `lesson_5`
--
ALTER TABLE `lesson_5`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=124;
--
-- AUTO_INCREMENT для таблицы `lesson_6`
--
ALTER TABLE `lesson_6`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `lesson_6_reviews`
--
ALTER TABLE `lesson_6_reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
