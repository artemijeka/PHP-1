-- phpMyAdmin SQL Dump
-- version 4.7.2
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Ноя 17 2017 г., 18:26
-- Версия сервера: 10.1.26-MariaDB
-- Версия PHP: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `php-1`
--

-- --------------------------------------------------------

--
-- Структура таблицы `lesson_5`
--

CREATE TABLE `lesson_5` (
  `ID` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `way` varchar(100) NOT NULL,
  `size` int(11) NOT NULL,
  `hits` float NOT NULL,
  `descriptionForImage` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `lesson_5`
--

INSERT INTO `lesson_5` (`ID`, `name`, `way`, `size`, `hits`, `descriptionForImage`) VALUES
(142, '1.jpg', '../data/uploads/', 137800, 2, ''),
(143, '2.jpg', '../data/uploads/', 85699, 2, '');

-- --------------------------------------------------------

--
-- Структура таблицы `lesson_6`
--

CREATE TABLE `lesson_6` (
  `ID` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `way` varchar(100) NOT NULL,
  `size` int(11) NOT NULL,
  `hits` float NOT NULL,
  `descriptionForImage` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `lesson_6`
--

INSERT INTO `lesson_6` (`ID`, `name`, `way`, `size`, `hits`, `descriptionForImage`) VALUES
(147, '1.jpg', '../data/uploads/', 137800, 0, 'Белочка.'),
(148, '2.jpg', '../data/uploads/', 85699, 6, 'Тигрюша.'),
(149, '3.jpg', '../data/uploads/', 208818, 0, 'Зебра...'),
(150, '4.jpg', '../data/uploads/', 50445, 4, 'Левушка...');

-- --------------------------------------------------------

--
-- Структура таблицы `lesson_6_reviews`
--

CREATE TABLE `lesson_6_reviews` (
  `id` int(11) NOT NULL,
  `userName` varchar(64) NOT NULL,
  `userEmail` varchar(64) NOT NULL,
  `userReview` varchar(1000) NOT NULL,
  `currentDate` varchar(24) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `lesson_6_reviews`
--

INSERT INTO `lesson_6_reviews` (`id`, `userName`, `userEmail`, `userReview`, `currentDate`) VALUES
(205, 'Артем', 'artem.kuznecov.samara@gmail.com', 'Прикольный сайт.', '15 November 2017 3:36'),
(207, 'Степан', 'stepan@who.ru', 'Немного изображения в галерее нехоршо сжимаются.', '15 November 2017 4:36'),
(208, 'Григорий', 'grigoriy@who.ru', 'Калькулятор не работает с процентами и не принимает математическое выражение в поле ввода :(', '15 November 2017 4:37'),
(209, 'Акакий', 'akak@abc.com', 'Интересно, что за тематика у этого сайта?', '16 November 2017 18:40');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `lesson_5`
--
ALTER TABLE `lesson_5`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `lesson_6`
--
ALTER TABLE `lesson_6`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `lesson_6_reviews`
--
ALTER TABLE `lesson_6_reviews`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `lesson_5`
--
ALTER TABLE `lesson_5`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=144;
--
-- AUTO_INCREMENT для таблицы `lesson_6`
--
ALTER TABLE `lesson_6`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=151;
--
-- AUTO_INCREMENT для таблицы `lesson_6_reviews`
--
ALTER TABLE `lesson_6_reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=210;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
